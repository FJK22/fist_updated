# Sort []({{ site.repo }}/blob/master/docs/_i18n/{{ site.lang }}/examples/sort.md)

---

## Basic Sort

Use `sortName`, `sortOrder`, `sortable` options, and `sortable`, `order` column options to set the basic sort of bootstrap table. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/18/embedded/html,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>

## Custom Sort

Use `sorter` column option to define the custom sort of bootstrap table. _by [@wenzhixin](https://github.com/wenzhixin)_

<iframe width="100%" height="300" data-src="http://jsfiddle.net/wenyi/e3nk137y/19/embedded/html,js,result" allowfullscreen="allowfullscreen" frameborder="0"></iframe>